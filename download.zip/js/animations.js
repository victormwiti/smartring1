gsap.registerPlugin(ScrollTrigger);

function toggleMenu(){
document.getElementById("mobileMenu").classList.toggle("hidden");
}

gsap.from(".hero-title",{y:50,opacity:0,duration:1});
gsap.from(".hero-sub",{opacity:0,delay:0.5});
gsap.from(".hero-btn",{opacity:0,delay:1});